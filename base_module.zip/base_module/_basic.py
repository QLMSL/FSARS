import torch.nn as nn

class ARFB(nn.Module):
    """Small receptive-field residual block"""
    def __init__(self, c):
        super().__init__()
        self.conv1 = nn.Conv2d(c, c, 3, 1, 1)
        self.conv2 = nn.Conv2d(c, c, 3, 1, 1)
        self.act = nn.ReLU(inplace=True)

    def forward(self, x):
        return x + self.conv2(self.act(self.conv1(x)))